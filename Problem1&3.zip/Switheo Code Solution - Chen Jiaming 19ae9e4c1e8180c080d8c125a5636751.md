# Switheo Code Solution  - Chen Jiaming

**Problem 1: Three ways to sum to n**

Provide 3 unique implementations of the following function in JavaScript.

**Input**: `n` - any integer

*Assuming this input will always produce a result lesser than `Number.MAX_SAFE_INTEGER`*.

**Output**: `return` - summation to `n`, i.e. `sum_to_n(5) === 1 + 2 + 3 + 4 + 5 === 15`.

```jsx
var sum_to_n_a = function(n) {
    let sum = 0;
    for (let i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
};

var sum_to_n_b = function(n) {
    return (n * (n + 1)) / 2;
};

var sum_to_n_c = function(n) {
    if (n === 1) {
        return 1;
    }
    return n + sum_to_n_c(n - 1);
};
```

Problem 3: Messy React：

```jsx
import React, { useState, useEffect, useMemo } from 'react';

// Define the interfaces for the wallet data
interface WalletBalance {
  currency: string;
  amount: number;
  blockchain: string;
}

interface FormattedWalletBalance extends WalletBalance {
  formatted: string;
}

// Dummy type for BoxProps; adjust as needed
interface BoxProps {
  [key: string]: any;
}

// API URL constant
const API_URL = "https://interview.switcheo.com/prices.json";

// Datasource class for fetching prices
class Datasource {
  private url: string;

  constructor(url: string) {
    this.url = url;
  }

  async getPrices(): Promise<Record<string, number>> {
    const response = await fetch(this.url);
    if (!response.ok) throw new Error('Network error');

    const data = await response.json();
    if (!Array.isArray(data)) throw new Error('Invalid data format');

    // Convert the array to a lookup object where currency is the key and price is the value
    return data.reduce((acc: Record<string, number>, item: { currency: string; price: number }) => ({
      ...acc,
      [item.currency]: item.price,
    }), {});
  }
}

// Function to determine the priority based on the blockchain type
const getPriority = (blockchain: string): number => {
  switch (blockchain) {
    case 'Osmosis':   return 100;
    case 'Ethereum':  return 50;
    case 'Arbitrum':  return 30;
    case 'Zilliqa':   return 20;
    case 'Neo':       return 20;
    default:          return -99;
  }
};

// Placeholder hook to simulate wallet balances
const useWalletBalances = (): WalletBalance[] => {
  // Sample data for demonstration
  return [
    { currency: "BTC", amount: 0.5, blockchain: "Ethereum" },
    { currency: "ETH", amount: 10, blockchain: "Ethereum" },
    { currency: "OSMO", amount: 100, blockchain: "Osmosis" },
  ];
};

// Placeholder WalletRow component for rendering each balance row
interface WalletRowProps {
  className?: string;
  amount: number;
  usdValue: number;
  formattedAmount: string;
}

const WalletRow: React.FC<WalletRowProps> = ({ className, amount, usdValue, formattedAmount }) => (
  <div className={className}>
    <span>Amount: {amount}</span> | <span>USD Value: {usdValue}</span> | <span>Formatted: {formattedAmount}</span>
  </div>
);

// Dummy styles placeholder; replace with your actual CSS or styling solution
const classes = {
  row: 'wallet-row',
};

interface Props extends BoxProps {}

// Main component that displays wallet information
const WalletPage: React.FC<Props> = (props) => {
  const { children, ...rest } = props;
  const balances = useWalletBalances();
  const [prices, setPrices] = useState<Record<string, number>>({});

  useEffect(() => {
    const controller = new AbortController();
    const datasource = new Datasource(API_URL);

    datasource.getPrices()
      .then(pricesData => {
        if (!controller.signal.aborted) {
          setPrices(pricesData);
        }
      })
      .catch(error => {
        if (!controller.signal.aborted) {
          console.error(error);
        }
      });

    // Cleanup: abort fetch if the component unmounts
    return () => controller.abort();
  }, []);

  // Memoize the sorted balances to avoid unnecessary recomputation on each render
  const sortedBalances = useMemo(() => {
    return balances
      .filter(balance => {
        const priority = getPriority(balance.blockchain);
        return priority > -99 && balance.amount > 0;
      })
      .sort((a, b) => {
        const aPriority = getPriority(a.blockchain);
        const bPriority = getPriority(b.blockchain);
        return bPriority - aPriority;
      });
  }, [balances]);

  // Map each balance to a WalletRow component
  const rows = sortedBalances.map(balance => {
    const uniqueKey = `${balance.blockchain}-${balance.currency}-${balance.amount}`;
    const usdValue = (prices[balance.currency] || 0) * balance.amount;
    
    return (
      <WalletRow
        key={uniqueKey}
        className={classes.row}
        amount={balance.amount}
        usdValue={usdValue}
        formattedAmount={balance.amount.toFixed()}
      />
    );
  });

  return (
    <div {...rest}>
      {rows}
      {children}
    </div>
  );
};

export default WalletPage;

```

Problem 2: Fancy Form : Check the attachment.